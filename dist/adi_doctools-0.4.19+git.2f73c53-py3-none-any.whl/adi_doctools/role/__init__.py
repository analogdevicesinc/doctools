from .common import common_setup
from .interref import interref_setup

setup = [
    common_setup,
    interref_setup
]
